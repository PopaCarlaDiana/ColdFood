package com.example.coldfood;

import android.os.Build;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

import java.io.Serializable;
import java.time.*;
import java.util.*;
import java.time.chrono.*;
import java.time.temporal.ChronoField;


@Entity(tableName = "listaAlimente")
public class Aliment implements Serializable {
    @Override
    public String toString() {
        return "Aliment{" +
                "id=" + id +
                ", nume='" + nume + '\'' +
                ", dataExpirare=" + dataExpirare +
                ", dataInceput=" + dataInceput +
                ", importanta=" + importanta +
                ", cantitate=" + cantitate +
                '}';
    }

    @PrimaryKey(autoGenerate = true)
    private int id;
    @ColumnInfo(name="nume_aliment")
    private String nume;
//    @ColumnInfo(name="data_expirare")
//    private LocalDate dataExpirare;
//    @ColumnInfo(name="data_inceput")
//    private LocalDate dataInceput;
    @ColumnInfo(name="data_expirare")
    private Integer dataExpirare;
    @ColumnInfo(name="data_inceput")
    private Integer dataInceput;
    @ColumnInfo(name="importanta")
    private boolean importanta;
    @ColumnInfo(name="cantitate")
    private int cantitate;

    public Aliment(String nume, Integer dataExpirare, Integer dataInceput, boolean importanta, int cantitate) {
        this.nume = nume;
        this.dataExpirare = dataExpirare;
        this.dataInceput = dataInceput;
        this.importanta = importanta;
        this.cantitate = cantitate;
    }

    @Ignore
    public Aliment(String nume, Integer dataExpirare, boolean importanta, int cantitate) {
        //System.out.println("OKKKKKKKKKKKKKKK-------CONSTRUCTOR\n");
        System.out.println(dataExpirare.toString()+'\n');
        this.nume = nume;
        this.dataExpirare = dataExpirare;
        this.importanta = importanta;
        this.cantitate = cantitate;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            //System.out.println("OKKKKKKKKKKKKKKK-------CONDITIE\n");
            //this.dataInceput = LocalDate.now();
            //this.dataInceput="11.12.2022";
            this.dataInceput=0;
        }
        //System.out.println("OKKKKKKKKKKKKKKK-------CONSTRUCTOR\n");
        System.out.println(this.dataExpirare.toString()+'\n');
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setDataInceput(Integer dataInceput) {
        this.dataInceput = dataInceput;
    }

    public Integer getDataInceput() {
//        String nrzile;
//        int i=0;
//        for(i=0;i<this.dataInceput.length();i++){
//            if(this.dataInceput.charAt(i)=='.')
//                break;
//            else
//                nrzile.
//        }
//        //String output = this.dataInceput.Substring(this.dataInceput.IndexOf('.') + 1);
//        String streetaddress= substr(this.dataInceput, 0, index(this.dataInceput, '.'));
//        this.dataInceput.Split('.').Last()
//        LocalDate localdate = LocalDate.of(nrani,nrluni,nrzile);
        return dataInceput;
    }

    public String getNume() {
        return nume;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

    public Integer getDataExpirare() {
        return dataExpirare;
    }

    public void setDataExpirare(Integer dataExpirare) {
        this.dataExpirare = dataExpirare;
    }

    public boolean isImportanta() {
        return importanta;
    }

    public void setImportanta(boolean importanta) {
        this.importanta = importanta;
    }

    public int getCantitate() {
        return cantitate;
    }

    public void setCantitate(int cantitate) {
        this.cantitate = cantitate;
    }

//    public int ZileRamasePanaLaExpirare(){
//        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
//            LocalDate presentDate= LocalDate.now();
//            if(this.dataExpirare.getYear()==2023)
//                return 365-(presentDate.getDayOfYear()-this.dataExpirare.getDayOfYear());
//            else
//                 return this.dataExpirare.getDayOfYear()-presentDate.getDayOfYear();
//        }
//        return 0;
//    }

    public int getFreshProcent(){
        int ziPrezent=3;
        int fresh = (this.getDataExpirare()-ziPrezent)*100/(this.getDataExpirare());
        if(fresh<0)
            return 0;
        return fresh;
//        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
//            LocalDate presentDate = LocalDate.now();
//            LocalDate dataDiferenta = LocalDate.of(2022,1,1);
//            int diffDataInceput;
//            if(this.dataInceput.getYear()==2023)
//                diffDataInceput = 365-(dataDiferenta.getDayOfYear()-this.dataInceput.getDayOfYear());
//            else
//                diffDataInceput = this.dataInceput.getDayOfYear()-dataDiferenta.getDayOfYear();
//
//            int diffDataPrezent;
//            if(presentDate.getYear()==2023)
//                diffDataPrezent = 365-(dataDiferenta.getDayOfYear()-presentDate.getDayOfYear());
//            else
//                diffDataPrezent = presentDate.getDayOfYear()-dataDiferenta.getDayOfYear();
//
//            int diffDataExpirare;
//            if(this.dataExpirare.getYear()==2023)
//                diffDataExpirare = 365-(dataDiferenta.getDayOfYear()-this.dataExpirare.getDayOfYear());
//            else
//                diffDataExpirare = this.dataExpirare.getDayOfYear()-dataDiferenta.getDayOfYear();
//
//            System.out.println(diffDataInceput+"  "+diffDataPrezent+" "+diffDataExpirare+"\n");
//
//            int dif = (diffDataExpirare-diffDataPrezent)*100;
//            //todo pasare dodo lol
//            if(diffDataExpirare-diffDataInceput==0)
//                return 50;
//            else{
//                dif=dif-(diffDataExpirare-diffDataInceput);
//                return dif;
//            }
//        }
        //return 50;
     //   return 0;
    }

    public boolean equals(Aliment aliment) {
        if (importanta == aliment.importanta && cantitate == aliment.cantitate && nume.equals(aliment.nume) && dataExpirare.equals(aliment.dataExpirare) && dataInceput.equals(aliment.dataInceput))
            return true;
        else
            return false;
    }

        public static Comparator<Aliment> AlimentAscendingFreshness = new Comparator<Aliment>() {
        @Override
        public int compare(Aliment f1, Aliment f2) {
            boolean ok=f1.getFreshProcent()>f2.getFreshProcent();
            if(ok==true)
                return 1;
            ok=f1.getFreshProcent()<f2.getFreshProcent();
            if(ok==true)
                return -1;
            return 0;
        }
    };


    public static Comparator<Aliment> AlimentDescendingFreshness = new Comparator<Aliment>() {
        @Override
        public int compare(Aliment f1, Aliment f2) {
            boolean ok=f1.getFreshProcent()<f2.getFreshProcent();
            if(ok==true)
                return 1;
            ok=f1.getFreshProcent()>f2.getFreshProcent();
            if(ok==true)
                return -1;
            return 0;
        }
    };

}
