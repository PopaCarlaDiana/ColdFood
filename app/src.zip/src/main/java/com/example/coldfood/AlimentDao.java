package com.example.coldfood;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.List;

@Dao
public interface AlimentDao {

    @Insert
    void insert(Aliment word);
//    @Query("INSERT INTO listaAlimente (nume_aliment) VALUES ()")
//    void insert(Aliment word);

    @Query("DELETE FROM listaAlimente")
    void deleteAll();

    @Query("DELETE FROM listaAlimente WHERE id = :id")
    void deleteById(int id);

//    @Query("DELETE FROM listaAlimente")
//    void deleteItem(Aliment a);

    @Query("SELECT * FROM listaAlimente ORDER BY id ASC")
    LiveData<List<Aliment>> getAlimente();

   // @Query("SELECT * FROM listaAlimente WHERE 'id'='1'")
    //LiveData<Aliment> getAliment();
}
